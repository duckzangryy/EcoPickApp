const { neon } = require('@neondatabase/serverless');
const sql = neon(process.env.DATABASE_URL || '');
const rewards = [
  { id: 'ex-001', title: 'Một ly cà phê size vừa', description: 'Đổi một ly cà phê size vừa tại cửa hàng đối tác.', points_cost: 300, image_url: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400', sponsor: 'Highlands Coffee', category: 'beverage', available_quantity: 45 },
  { id: 'ex-002', title: 'Một chai nước suối', description: 'Nhận một chai nước suối tại điểm đổi quà đối tác.', points_cost: 100, image_url: 'https://images.unsplash.com/photo-1523362628745-0c100150b3a2?w=400', sponsor: 'Nhà tài trợ EcoPick', category: 'beverage', available_quantity: 80 },
  { id: 'ex-003', title: 'Voucher giảm 50.000đ', description: 'Voucher mua sắm thân thiện môi trường, dùng một lần.', points_cost: 250, image_url: 'https://images.unsplash.com/photo-1544816155-12df9643f363?w=400', sponsor: 'EcoMart', category: 'voucher', available_quantity: 100 },
];

async function main() {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required');
  for (const item of rewards) {
    await sql`INSERT INTO exchange_items (id, title, description, points_cost, image_url, sponsor, category, available_quantity)
      VALUES (${item.id}, ${item.title}, ${item.description}, ${item.points_cost}, ${item.image_url}, ${item.sponsor}, ${item.category}, ${item.available_quantity})
      ON CONFLICT (id) DO NOTHING`;
  }
  console.log(`Seeded ${rewards.length} sponsor rewards.`);
}

main().catch((error) => { console.error(error); process.exitCode = 1; });
