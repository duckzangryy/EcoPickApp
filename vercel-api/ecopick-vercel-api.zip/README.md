# EcoPick API for Vercel + Neon

ZIP này chứa API serverless độc lập, không kèm app Expo, `.env`, database người dùng hoặc `node_modules`.

## Có gì

- Đăng ký/đăng nhập bằng JWT, hồ sơ cơ bản.
- Gửi báo cáo, cộng điểm theo severity (`low` 10, `medium` 25, `high` 50, `critical` 75), lịch sử điểm.
- Danh sách sự kiện đọc từ bảng `app_data`.
- Danh sách quà mẫu, đổi quà trừ điểm và tồn kho trong PostgreSQL, sinh mã QR redeem; danh sách/chi tiết quà đã đổi chỉ truy cập được bởi chủ sở hữu.
- Upload multipart ảnh đến Vercel Blob; dùng `BLOB_STORE_ID` (OIDC) hoặc `BLOB_READ_WRITE_TOKEN`.

Chưa có: các endpoint social/chat/notification, Google/Apple OAuth, email thật cho OTP, giao dịch sponsor xác minh mã, và những endpoint app khác không nêu trong danh sách trên. Endpoint chưa hỗ trợ trả `404` có mã lỗi rõ ràng. Không dùng tài khoản mẫu/password mặc định từ máy dev.

## Trạng thái đã triển khai

Project Vercel `ecopick-api`, production URL `https://ecopick-api-iota.vercel.app` (root directory đặt là `vercel-api`, Postgres Neon đã có schema + 3 quà mẫu, chưa có tài khoản người dùng). Các endpoint đã kiểm chứng: `/health`, đăng ký/đăng nhập, `/api/users/userinfo/`, `/api/v1/users/me`, gửi báo cáo cộng điểm theo severity, `/api/badge/exchange-items/`, redeem trừ điểm + tồn kho + sinh mã, `/api/badge/redemptions/` (chỉ chủ sở hữu), `/api/chat/point-logs/`.

Rewrite phải giữ cả biến thể có `/` cuối (`/api/:path*/`), vì app Expo gọi endpoint kèm dấu `/`; thiếu rule này Vercel trả `404 NOT_FOUND` trước khi tới Function.


## Triển khai

1. Tạo project Vercel và Neon Postgres (Neon có thể kết nối qua Vercel Marketplace). ZIP hiện chưa được deploy, và không tạo database thay bạn.
2. Từ thư mục đã giải nén, tạo database schema:

   ```bash
   psql "$DATABASE_URL" -f db/schema.sql
   ```

3. Thêm Environment Variables trong Vercel Project Settings → Environment Variables:
   - `DATABASE_URL`: connection string của Neon Postgres.
   - `JWT_SECRET`: random secret dài ít nhất 32 bytes.
   - `CORS_ORIGIN`: production origin cụ thể của app/web khi có; `*` chỉ để thử nghiệm.
   - Blob: nếu Blob store nối vào project qua Vercel Marketplace, Vercel tự cấp `BLOB_STORE_ID` (OIDC, không cần token). Chỉ khai `BLOB_READ_WRITE_TOKEN` khi tạo store kiểu cũ.
4. Deploy project bằng Vercel CLI từ thư mục API đã giải nén:

   ```bash
   npm install
   npx vercel
   ```

   Hoặc từ dashboard: New Project → Import/Upload project, chọn thư mục này. Không chạy `npm start` trên Vercel production; Vercel tự nhận `api/index.js`.
5. Seed chỉ quà mẫu (idempotent; không seed user/password):

   ```bash
   DATABASE_URL='…' npm run db:seed
   ```

6. Đặt `EXPO_PUBLIC_API_BASE_URL` phía app thành URL deployment sau khi API và DB kiểm tra thành công.

## Lưu ý endpoint

`api/index.js` dùng một Vercel Function nhận `/api/*`; rewrite giữ path gốc trong query `route` để dispatcher nhận đúng endpoint legacy/v1. Kiểm tra `/health` và route smoke test sau khi deploy trước khi cập nhật app.

Các đường dẫn đã hỗ trợ chính:

- `POST /api/v1/auth/register`, `/api/users/signup/`
- `POST /api/v1/auth/login`, `/api/users/signin/`
- `POST /api/v1/auth/verify-email`, `/api/v1/auth/forgot-password`, `/api/v1/auth/reset-password`, `/api/v1/auth/refresh`, `/api/v1/auth/logout`
- `GET/PATCH /api/v1/users/me`, `GET /api/users/userinfo/`, avatar, stats
- `GET/POST /api/v1/reports`, `/api/report/reports/`; multipart image cần Blob token
- `GET /api/photos`, `POST /api/upload`, `DELETE /api/photos/:id`
- `GET /api/event/events/` (cần seed events vào `app_data` thủ công)
- `GET /api/badge/exchange-items/`, `POST /api/badge/exchange-items/:id/redeem/`
- `GET /api/badge/redemptions/`, `GET /api/badge/redemptions/:id/`
- `GET /api/chat/point-logs/`, `GET /api/v1/points/history`

## Neon transaction behavior

Report points and redemption updates are database functions defined in `db/schema.sql`, called as single SQL statements. This keeps report + balance + log and redemption + balance + stock + code updates atomic with Neon HTTP driver. Schema must be applied before deploying routes.

## Security / demo boundaries

- Do not commit `.env` or put `DATABASE_URL`, Blob token, or JWT secret into source/ZIP.
- Register creates unverified account and an OTP row, but API does not send email. In development only, OTP appears in response; production needs email delivery before enabling verification UX.
- This is starter API packaging, not production security certification. Add rate limiting, audit/monitoring, real mail, rate-limited auth, database backups, storage lifecycle policies, and sponsor-side code validation before production use.
- Neon stores durable app state; Vercel function filesystem is not used for mutable data.
