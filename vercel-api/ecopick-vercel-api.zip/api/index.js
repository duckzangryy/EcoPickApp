const { neon } = require('@neondatabase/serverless');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { put } = require('@vercel/blob');
const crypto = require('node:crypto');

const sql = () => {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is not configured');
  return neon(process.env.DATABASE_URL);
};

const POINTS_BY_SEVERITY = { low: 10, medium: 25, high: 50, critical: 75 };
// PL/pgSQL RAISE EXCEPTION surfaces as a plain PG error; map business codes to HTTP.
const DOMAIN_ERRORS = {
  USER_NOT_FOUND: [404, 'Vui lòng đăng nhập lại'],
  REWARD_NOT_FOUND: [404, 'Không tìm thấy phần thưởng'],
  OUT_OF_STOCK: [409, 'Phần thưởng đã hết'],
  INSUFFICIENT_POINTS: [409, 'Bạn không đủ điểm để đổi phần thưởng này'],
};
function failDomain(res, error) {
  const code = Object.keys(DOMAIN_ERRORS).find((key) => String(error?.message || '').includes(key));
  if (!code) return false;
  const [status, message] = DOMAIN_ERRORS[code];
  fail(res, status, code, message);
  return true;
}
const json = (res, status, body) => { res.statusCode = status; res.setHeader('Content-Type', 'application/json; charset=utf-8'); res.end(JSON.stringify(body)); };
const fail = (res, status, code, message) => json(res, status, { success: false, error: { code, message, details: [] }, detail: message });

function bodyJson(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (chunk) => { raw += chunk; if (raw.length > 1_000_000) reject(new Error('Request body too large')); });
    req.on('end', () => { try { resolve(raw ? JSON.parse(raw) : {}); } catch { resolve({}); } });
    req.on('error', reject);
  });
}

function currentUser(req, res) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!token || !process.env.JWT_SECRET) { fail(res, 401, 'UNAUTHORIZED', 'Vui lòng đăng nhập'); return null; }
  try { return jwt.verify(token, process.env.JWT_SECRET); }
  catch { fail(res, 401, 'UNAUTHORIZED', 'Token không hợp lệ hoặc đã hết hạn'); return null; }
}

function tokenFor(user) {
  if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET is not configured');
  return jwt.sign({ userId: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '30d' });
}

function userShape(row) {
  if (!row) return null;
  return {
    id: row.id, email: row.email, fullname: row.fullname, full_name: row.fullname,
    username: row.username, avatar: row.avatar, avatar_url: row.avatar,
    bio: row.bio, role: row.role, level: row.level, eco_points: row.eco_points,
    total_reports: row.total_reports, total_events: row.total_events, total_trees: row.total_trees,
    followers_count: 0, follower_count: 0, following_count: 0,
    is_verified: row.is_verified, is_active: row.is_active, is_staff: row.is_staff,
    created_at: row.created_at, updated_at: row.updated_at,
  };
}

async function parseMultipart(req) {
  const fields = {};
  let uploaded = null;
  await new Promise((resolve, reject) => {
    let parser;
    try { parser = require('busboy')({ headers: req.headers, limits: { fileSize: 4 * 1024 * 1024, files: 1 } }); }
    catch (error) { reject(error); return; }
    parser.on('field', (name, value) => { fields[name] = value; });
    parser.on('file', (name, stream, info) => {
      const chunks = [];
      stream.on('data', (chunk) => chunks.push(chunk));
      stream.on('limit', () => reject(new Error('Ảnh vượt giới hạn 4MB')));
      stream.on('end', () => { uploaded = { filename: info.filename, mimeType: info.mimeType, buffer: Buffer.concat(chunks) }; });
    });
    parser.on('error', reject);
    parser.on('finish', resolve);
    req.pipe(parser);
  });
  return { fields, uploaded };
}

async function uploadImage(uploaded) {
  if (!uploaded) return '';
  if (!process.env.BLOB_READ_WRITE_TOKEN && !process.env.BLOB_STORE_ID) throw new Error('Blob storage is not configured (BLOB_READ_WRITE_TOKEN or BLOB_STORE_ID)');
  const safeName = (uploaded.filename || 'report.jpg').replace(/[^a-zA-Z0-9._-]/g, '_');
  const blob = await put(`reports/${Date.now()}-${safeName}`, uploaded.buffer, { access: 'public', contentType: uploaded.mimeType || 'image/jpeg' });
  return blob.url;
}

async function createReport(req, res, database, user, fields, imageUrl) {
  const severity = Object.hasOwn(POINTS_BY_SEVERITY, fields.severity) ? fields.severity : 'medium';
  const points = POINTS_BY_SEVERITY[severity];
  const id = `rep-${crypto.randomUUID()}`;
  const now = new Date().toISOString();
  const latitude = Number(fields.latitude || fields.lat) || 12.6828;
  const longitude = Number(fields.longitude || fields.lng) || 108.0378;
  const photoUrls = imageUrl ? [imageUrl] : (Array.isArray(fields.photo_urls) ? fields.photo_urls : (fields.photo_urls ? JSON.parse(fields.photo_urls) : []));
  const report = {
    id, user_id: user.userId, latitude, longitude,
    address: fields.address || fields.location || fields.title || 'Đắk Lắk, Việt Nam',
    severity, waste_types: fields.wasteTypes ? fields.wasteTypes.split(',').map((v) => v.trim()) : ['plastic'],
    description: fields.description || '', status: fields.status || 'reported', upvote_count: 0, comment_count: 0,
    photo_urls: photoUrls, created_at: now, updated_at: now,
  };
  const [result] = await database`SELECT ecopick_create_report(
    ${user.userId}, ${report.id}, ${latitude}, ${longitude}, ${report.address}, ${severity},
    ${JSON.stringify(report.waste_types)}::jsonb, ${report.description}, ${JSON.stringify(report.photo_urls)}::jsonb
  ) AS value`;
  if (!result?.value) throw new Error('Could not persist report and points');
  return result.value;
}

async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', process.env.CORS_ORIGIN || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization,Content-Type,Accept,X-Requested-With');
  if (req.method === 'OPTIONS') { res.statusCode = 204; return res.end(); }

  const database = sql();
  const originalUrl = req.url || '/';
  const url = new URL(originalUrl, `https://${req.headers.host || 'localhost'}`);
  const routedPath = url.searchParams.get('route');
  const forwardedPath = req.headers['x-original-uri'] || req.headers['x-vercel-original-path'] || req.headers['x-forwarded-uri'];
  const path = (routedPath || (forwardedPath ? new URL(forwardedPath, url).pathname : url.pathname)).replace(/\/+$/, '') || '/';
  const method = req.method.toUpperCase();

  if (path === '/' || path === '/health' || path === '/api/health' || path === '/api/v1/health') {
    return json(res, 200, { success: true, ok: true, message: 'EcoPick API is running', version: '1.0.0' });
  }

  if ((path === '/api/v1/auth/register' || path === '/api/users/signup') && method === 'POST') {
    const body = await bodyJson(req);
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (!email || password.length < 8) return fail(res, 400, 'VALIDATION_ERROR', 'Email bắt buộc; mật khẩu tối thiểu 8 ký tự');
    const fullname = body.fullName || body.fullname || email.split('@')[0];
    const username = String(body.username || email.split('@')[0]).toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 40) || `user_${Date.now()}`;
    const id = `user-${crypto.randomUUID()}`;
    const hash = await bcrypt.hash(password, 12);
    try {
      const [row] = await database`INSERT INTO users (id,email,password_hash,fullname,username,eco_points,is_verified)
        VALUES (${id},${email},${hash},${fullname},${username},0,false) RETURNING *`;
      const user = userShape(row);
      const otp = crypto.randomInt(100000, 999999).toString();
      await database`INSERT INTO otps(email,otp,expires_at) VALUES(${email},${otp},now()+interval '15 minutes') ON CONFLICT(email) DO UPDATE SET otp=EXCLUDED.otp,expires_at=EXCLUDED.expires_at`;
      return json(res, 201, { success: true, data: { user, message: 'Đăng ký thành công', otp: process.env.NODE_ENV === 'development' ? otp : undefined }, id, email, message: 'Đăng ký thành công' });
    } catch (error) {
      if (error.code === '23505') return fail(res, 409, 'EMAIL_EXISTS', 'Email hoặc username đã được sử dụng');
      throw error;
    }
  }

  if ((path === '/api/v1/auth/login' || path === '/api/users/signin') && method === 'POST') {
    const body = await bodyJson(req);
    const email = String(body.email || '').trim().toLowerCase();
    const [row] = await database`SELECT * FROM users WHERE email=${email} AND is_active=true`;
    if (!row || !await bcrypt.compare(String(body.password || ''), row.password_hash)) return fail(res, 401, 'INVALID_CREDENTIALS', 'Email hoặc mật khẩu không chính xác');
    const user = userShape(row);
    const accessToken = tokenFor(user);
    const refreshToken = jwt.sign({ userId: user.id, email: user.email, type: 'refresh' }, process.env.JWT_SECRET, { expiresIn: '30d' });
    return json(res, 200, { success: true, data: { user, accessToken, refreshToken }, access_token: accessToken, accessToken, refresh_token: refreshToken, refreshToken, token_type: 'Bearer', expires_in: 2592000, user });
  }

  if (path === '/api/v1/auth/refresh' && method === 'POST') {
    const body = await bodyJson(req);
    try {
      const token = body.refreshToken || body.refresh_token;
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      if (payload.type !== 'refresh') throw new Error('Invalid refresh token');
      const [row] = await database`SELECT * FROM users WHERE id=${payload.userId} AND is_active=true`;
      if (!row) return fail(res, 401, 'UNAUTHORIZED', 'Tài khoản không còn tồn tại');
      const accessToken = tokenFor(userShape(row));
      return json(res, 200, { success: true, data: { accessToken, refreshToken: token }, access_token: accessToken, refresh_token: token });
    } catch { return fail(res, 401, 'UNAUTHORIZED', 'Refresh token không hợp lệ'); }
  }

  if (path === '/api/v1/auth/logout' && method === 'POST') return json(res, 200, { success: true, data: { message: 'Đăng xuất thành công' } });
  if ((path === '/api/v1/auth/google' || path === '/api/v1/auth/apple') && method === 'POST') return fail(res, 501, 'NOT_CONFIGURED', 'OAuth chưa được cấu hình cho deployment này');

  if (path === '/api/v1/auth/verify-email' && method === 'POST') {
    const body = await bodyJson(req);
    const [stored] = await database`SELECT otp FROM otps WHERE email=${String(body.email || '').toLowerCase()} AND expires_at > now()`;
    if (!stored || stored.otp !== String(body.otp || body.code || '')) return fail(res, 400, 'INVALID_OTP', 'Mã xác thực không hợp lệ hoặc đã hết hạn');
    const [row] = await database`UPDATE users SET is_verified=true, updated_at=now() WHERE email=${String(body.email || '').toLowerCase()} RETURNING *`;
    await database`DELETE FROM otps WHERE email=${String(body.email || '').toLowerCase()}`;
    if (!row) return fail(res, 404, 'NOT_FOUND', 'Không tìm thấy tài khoản');
    return json(res, 200, { success: true, data: { user: userShape(row), message: 'Xác thực email thành công' } });
  }

  if ((path === '/api/v1/auth/forgot-password' || path === '/api/v1/auth/reset-password') && method === 'POST') {
    const body = await bodyJson(req);
    const email = String(body.email || '').trim().toLowerCase();
    const [user] = await database`SELECT id FROM users WHERE email=${email}`;
    if (!user) return fail(res, 404, 'NOT_FOUND', 'Email không tồn tại');
    if (path.endsWith('forgot-password')) {
      const otp = crypto.randomInt(100000, 999999).toString();
      await database`INSERT INTO otps(email,otp,expires_at) VALUES(${email},${otp},now()+interval '15 minutes') ON CONFLICT(email) DO UPDATE SET otp=EXCLUDED.otp,expires_at=EXCLUDED.expires_at`;
      return json(res, 200, { success: true, data: { email, message: 'Mã đặt lại mật khẩu đã tạo', otp: process.env.NODE_ENV === 'development' ? otp : undefined } });
    }
    const otp = String(body.otp || body.code || '');
    const password = String(body.newPassword || body.new_password || body.password || '');
    if (password.length < 8) return fail(res, 400, 'VALIDATION_ERROR', 'Mật khẩu mới tối thiểu 8 ký tự');
    const [stored] = await database`SELECT otp FROM otps WHERE email=${email} AND expires_at > now()`;
    if (!stored || stored.otp !== otp) return fail(res, 400, 'INVALID_OTP', 'Mã xác thực không hợp lệ hoặc đã hết hạn');
    const hash = await bcrypt.hash(password, 12);
    await database`UPDATE users SET password_hash=${hash},updated_at=now() WHERE id=${user.id}`;
    await database`DELETE FROM otps WHERE email=${email}`;
    return json(res, 200, { success: true, data: { message: 'Đặt lại mật khẩu thành công' } });
  }

  if (path === '/api/v1/users/me' || path === '/api/users/userinfo') {
    const auth = currentUser(req, res); if (!auth) return;
    if (method === 'GET') {
      const [row] = await database`SELECT * FROM users WHERE id=${auth.userId}`;
      if (!row) return fail(res, 404, 'NOT_FOUND', 'Không tìm thấy tài khoản');
      const user = userShape(row);
      return json(res, 200, { success: true, data: { ...user, stats: { totalReports: user.total_reports, totalEvents: user.total_events, treesPlanted: user.total_trees, followerCount: 0, followingCount: 0 } }, ...user });
    }
    if (method === 'PATCH' || method === 'PUT') {
      const body = await bodyJson(req);
      const fullName = body.fullname || body.fullName;
      const [row] = await database`UPDATE users SET fullname=COALESCE(${fullName || null},fullname), avatar=COALESCE(${body.avatarUrl || body.avatar || null},avatar), bio=COALESCE(${body.bio || null},bio), updated_at=now() WHERE id=${auth.userId} RETURNING *`;
      return json(res, 200, { success: true, data: userShape(row), ...userShape(row) });
    }
    return fail(res, 405, 'METHOD_NOT_ALLOWED', 'Method not allowed');
  }

  if (path === '/api/v1/users/me/avatar' && method === 'POST') {
    const auth = currentUser(req, res); if (!auth) return;
    const body = await bodyJson(req);
    const [row] = await database`UPDATE users SET avatar=${body.avatarUrl || body.avatar || ''}, updated_at=now() WHERE id=${auth.userId} RETURNING *`;
    return json(res, 200, { success: true, data: { avatarUrl: row.avatar } });
  }

  if ((path === '/api/v1/users/me/stats' || /^\/api\/v1\/users\/[^/]+\/stats$/.test(path)) && method === 'GET') {
    const auth = currentUser(req, res); if (!auth) return;
    const [row] = await database`SELECT * FROM users WHERE id=${auth.userId}`;
    return json(res, 200, { success: true, data: { totalReports: row.total_reports, totalEvents: row.total_events, treesPlanted: row.total_trees, ecoPoints: row.eco_points, level: row.level, followerCount: 0, followingCount: 0, streakDays: 0, rank: 0 } });
  }

  if (path === '/api/photos' && method === 'GET') {
    const photos = await database`SELECT data FROM app_data WHERE collection='map_photos' ORDER BY created_at DESC`;
    return json(res, 200, photos.map((row) => row.data));
  }

  const photoDelete = path.match(/^\/api\/photos\/([^/]+)$/);
  if (photoDelete && method === 'DELETE') {
    const [deleted] = await database`DELETE FROM app_data WHERE collection='map_photos' AND id=${photoDelete[1]} RETURNING id`;
    if (!deleted) return fail(res, 404, 'NOT_FOUND', 'Không tìm thấy ảnh');
    return json(res, 200, { success: true, message: 'Deleted photo' });
  }

  if (path === '/api/upload' && method === 'POST') {
    const auth = currentUser(req, res); if (!auth) return;
    const { fields, uploaded } = await parseMultipart(req);
    const imageUrl = await uploadImage(uploaded);
    const result = await createReport(req, res, database, auth, fields, imageUrl);
    const report = result.report;
    const photo = {
      id: report.id.replace(/^rep-/, ''), name: fields.uploader || fields.reporter_name || 'EcoPick Volunteer',
      uploader: fields.uploader || fields.reporter_name || 'EcoPick Volunteer', title: report.address,
      userid: auth.email, thumb: imageUrl, lat: report.latitude, lng: report.longitude,
      hasGps: true, outside: false, createdAt: Date.now(), source: 'app',
    };
    await database`INSERT INTO app_data (collection,id,user_id,data) VALUES ('map_photos',${photo.id},${auth.userId},${JSON.stringify(photo)}::jsonb)`;
    return json(res, 201, { success: true, ...photo, pointsEarned: result.pointsEarned, newTotal: result.newTotal });
  }

  if (path === '/api/v1/reports' || path === '/api/report/reports') {
    if (method === 'GET') {
      const rows = await database`SELECT * FROM reports ORDER BY created_at DESC`;
      const reports = rows.map((row) => ({ ...row, waste_types: row.waste_types, photo_urls: row.photo_urls }));
      return json(res, 200, path.includes('/v1/') ? { success: true, data: reports, results: reports } : reports);
    }
    if (method === 'POST') {
      const auth = currentUser(req, res); if (!auth) return;
      const contentType = req.headers['content-type'] || '';
      let fields; let uploaded;
      if (contentType.includes('multipart/form-data')) ({ fields, uploaded } = await parseMultipart(req));
      else fields = await bodyJson(req);
      const imageUrl = await uploadImage(uploaded);
      const result = await createReport(req, res, database, auth, fields, imageUrl);
      return json(res, 201, { success: true, data: result, ...result.report, pointsEarned: result.pointsEarned, newTotal: result.newTotal });
    }
  }

  const rewardPath = path.match(/^\/api\/badge\/exchange-items\/([^/]+)\/redeem$/);
  if ((path === '/api/badge/exchange-items' || path === '/api/v1/rewards') && method === 'GET') {
    const items = await database`SELECT id,title,description,points_cost,image_url,sponsor,category,available_quantity FROM exchange_items ORDER BY id`;
    return json(res, 200, path.includes('/v1/') ? { success: true, data: items } : items);
  }

  if (rewardPath && method === 'POST') {
    const auth = currentUser(req, res); if (!auth) return;
    const newId = `red-${crypto.randomUUID()}`;
    const code = `ECO-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
    const [result] = await database`SELECT ecopick_redeem(${auth.userId},${rewardPath[1]},${newId},${code}) AS value`;
    if (!result?.value) throw new Error('Could not persist redemption');
    return json(res, 201, { success: true, data: result.value });
  }

  if (path === '/api/badge/redemptions' && method === 'GET') {
    const auth = currentUser(req, res); if (!auth) return;
    const rows = await database`SELECT * FROM redemptions WHERE user_id=${auth.userId} ORDER BY created_at DESC`;
    return json(res, 200, rows);
  }

  const redemptionDetail = path.match(/^\/api\/badge\/redemptions\/([^/]+)$/);
  if (redemptionDetail && method === 'GET') {
    const auth = currentUser(req, res); if (!auth) return;
    const [row] = await database`SELECT * FROM redemptions WHERE id=${redemptionDetail[1]} AND user_id=${auth.userId}`;
    return row ? json(res, 200, row) : fail(res, 404, 'NOT_FOUND', 'Không tìm thấy phần thưởng đã đổi');
  }

  if ((path === '/api/chat/point-logs' || path === '/api/v1/points/history') && method === 'GET') {
    const auth = currentUser(req, res); if (!auth) return;
    const logs = await database`SELECT id,user_id,points,action,reason,reference_id,created_at FROM point_logs WHERE user_id=${auth.userId} ORDER BY created_at DESC LIMIT 100`;
    return json(res, 200, { success: true, data: logs, results: logs });
  }

  if ((path === '/api/event/events' || path === '/api/v1/events') && method === 'GET') {
    const rows = await database`SELECT data FROM app_data WHERE collection='events' ORDER BY created_at DESC`;
    const events = rows.map((row) => row.data);
    return json(res, 200, path.includes('/v1/') ? { success: true, data: { events }, events } : events);
  }

  const eventDetail = path.match(/^\/api\/(?:v1\/)?(?:event\/)?events\/([^/]+)$/);
  if (eventDetail && method === 'GET') {
    const [event] = await database`SELECT data FROM app_data WHERE collection='events' AND id=${eventDetail[1]}`;
    return event ? json(res, 200, { success: true, data: event.data, ...event.data }) : fail(res, 404, 'NOT_FOUND', 'Không tìm thấy sự kiện');
  }

  return fail(res, 404, 'NOT_FOUND', `Endpoint ${method} ${path} chưa được đóng gói`);
}

module.exports = async (req, res) => {
  try { await handler(req, res); }
  catch (error) {
    console.error('EcoPick API error:', error);
    if (!res.headersSent && !failDomain(res, error)) fail(res, 500, 'INTERNAL_ERROR', process.env.NODE_ENV === 'development' ? error.message : 'Lỗi máy chủ');
    else res.end();
  }
};
